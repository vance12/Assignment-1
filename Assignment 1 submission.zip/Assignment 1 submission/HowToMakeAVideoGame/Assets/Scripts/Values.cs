﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Values : MonoBehaviour
{

    public InputField playerName;
    public Text nameField;
    public Slider slider;
    public Text sliderTxt;

    // Update is called once per frame
    void Update()
    {
        nameField.text = playerName.text.ToString();
        sliderTxt.text = slider.value.ToString();
    }
}
