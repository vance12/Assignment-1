﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScenes : MonoBehaviour
{
    public void loadStartScene()
    {
        SceneManager.LoadScene("Start");
    }

    public void loadLevel1()
    {
        SceneManager.LoadScene("Level01");
    }

    public void loadLevel2()
    {
        SceneManager.LoadScene("Level02");
    }

    public void loadEnd()
    {
        //SceneManager.LoadScene("Level 01");
    }
}
